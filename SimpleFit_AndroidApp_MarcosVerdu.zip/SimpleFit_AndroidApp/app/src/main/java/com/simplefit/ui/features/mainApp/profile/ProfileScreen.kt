package com.simplefit.ui.features.mainApp.profile

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun ProfileScreen()
{
    Text(text = "Profile Screen")
}