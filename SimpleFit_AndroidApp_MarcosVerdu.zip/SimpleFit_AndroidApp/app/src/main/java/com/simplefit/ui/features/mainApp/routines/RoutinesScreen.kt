package com.simplefit.ui.features.mainApp.routines

import androidx.compose.material3.Text
import androidx.compose.runtime.Composable

@Composable
fun RoutinesScreen()
{
    Text(text = "Routines Screen")
}