package com.simplefit.models

data class Dietas(
    val id: Int,
)