package com.simplefit.ui.features.mainApp

class MainAppViewModel { //primero probar solo usando el mail del viewmodel de home y si no es factible, meter el email en este para que todos accedan desde este

}