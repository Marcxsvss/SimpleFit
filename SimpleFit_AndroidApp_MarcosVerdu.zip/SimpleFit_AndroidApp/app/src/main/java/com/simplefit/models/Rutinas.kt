package com.simplefit.models

data class Rutinas(
  val id:Int,
)
